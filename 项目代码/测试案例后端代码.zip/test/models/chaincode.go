package models

/*
	我们会使用fabric-sdk-go工具,在client端完成区块链数据的读写操作
 */

import (
	"github.com/hyperledger/fabric-sdk-go/api/apitxn"
	"github.com/hyperledger/fabric-sdk-go/def/fabapi"
	"github.com/astaxie/beego"
)

type ChainCodeSpec struct {
	// 操作区块
	client      apitxn.ChannelClient
	chainCodeId string
}

func (this *ChainCodeSpec) ChainCodeUpdate(function string, args [][]byte) (response []byte, err error) {
	// add update
	request := apitxn.ExecuteTxRequest{ChaincodeID: this.chainCodeId, Fcn: function, Args: args}
	id, err := this.client.ExecuteTx(request)
	return []byte(id.ID), err
}

func (this *ChainCodeSpec) ChainCodeQuery(function string, args [][]byte) (response []byte, err error) {
	// query
	request := apitxn.QueryRequest{this.chainCodeId, function, args}
	return this.client.Query(request)
	//return nil, nil
}

/*
	依据配置文件(xxx1.yaml),创建SDK.
	最常见的错误是证书配置路径问题
 */
func getSDK(config string) (*fabapi.FabricSDK, error) {
	options := fabapi.Options{ConfigFile: config}
	sdk, err := fabapi.NewSDK(options)

	if err != nil {
		beego.Error(err.Error())
	}
	return sdk, err
}

/*
	初始化ChainCodeSpec方法
 */
func Initialize(channelId string, userId string, chainCodeId string) (*ChainCodeSpec, error) {
	config := beego.AppConfig.String("CORE_XXX1_CONFIG_FILE")
	sdk, err := getSDK(config)
	if err != nil {
		return nil, err
	}
	client, err := sdk.NewChannelClient(channelId, userId)
	if err != nil {
		beego.Error(err.Error())
		return nil, err
	}

	return &ChainCodeSpec{client, chainCodeId}, nil
}

/**
	回收资源
 */
func (this *ChainCodeSpec) Close(){
	this.client.Close()
}
