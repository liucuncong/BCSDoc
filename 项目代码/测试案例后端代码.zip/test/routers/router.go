package routers

import (
	"github.com/astaxie/beego"
	"test/controllers"
)

func init() {
	// 当接收到一个http请求,/test 讲交给MainController中的GetValue方法(get请求--get:GetValue)
	beego.Router("/test",&controllers.MainController{},"get:GetValue")
	// 接收请求 /test post请求(post:SetValue)
	beego.Router("/test",&controllers.MainController{},"post:SetValue")
}
