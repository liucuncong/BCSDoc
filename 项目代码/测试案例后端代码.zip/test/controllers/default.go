package controllers

import (
	"github.com/astaxie/beego"
	"test/models"
)

type MainController struct {
	// 需要继承beego.Controller
	beego.Controller
}

/*
	读数据的方法
 */
func (this *MainController) GetValue() {
	key := this.GetString("key")
	if key == "" {
		// 没有传递需要的参数 key
		// this.Ctx.ResponseWriter.WriteHeader(400)
		// this.Ctx.ResponseWriter.Write([]byte("Request parameter key can't be empty"))
		handleResponse(this, 400, "Request parameter key can't be empty")
	}
	beego.Info("key:", key)

	// 依据key获取区块中记录的value信息,需要通过models中操作fabric-sdk-go,完成信息的读取
	var (
		channelId   = beego.AppConfig.String("channel_id")
		userId      = beego.AppConfig.String("useid")
		chainCodeId = beego.AppConfig.String("chaincode_id")
	)
	ccs, err := models.Initialize(channelId, userId, chainCodeId)
	if err != nil {
		handleResponse(this, 500, err.Error())
		return
	}
	defer ccs.Close()
	// chaincode查询需要的参数组装
	var args [][]byte
	args = append(args, []byte(key))

	data, err := ccs.ChainCodeQuery("get", args)

	if err != nil {
		handleResponse(this, 500, err.Error())
		return
	}

	// 假设已经读到信息
	//var data []byte
	// this.Ctx.ResponseWriter.WriteHeader(200)
	// this.Ctx.ResponseWriter.Write(data)
	handleResponse(this, 200, data)
}

/*
	写数据方法
 */
func (this *MainController) SetValue() {
	key := this.GetString("key")
	value := this.GetString("value")

	if key == "" || value == "" {
		handleResponse(this, 400, "Request parameter key(or value) can't be empty")
		return
	}
	beego.Info(key + ":" + value)

	// 写数据
	//var data []byte
	var(
		channelId=beego.AppConfig.String("channel_id")
		userId=beego.AppConfig.String("useid")
		chainCodeId=beego.AppConfig.String("chaincode_id")
	)
	ccs, err := models.Initialize(channelId, userId, chainCodeId)
	if err !=nil{
		handleResponse(this, 500, err.Error())
		return
	}
	defer ccs.Close()

	// 传递参数
	var args [][]byte
	args=append(args, []byte(key))
	args=append(args, []byte(value))

	response, err := ccs.ChainCodeUpdate("set", args)

	if err !=nil{
		handleResponse(this, 500, err.Error())
		return
	}

	// 写数据成功的回复
	handleResponse(this, 200, response)

}

/*
	处理数据回复
 */
func handleResponse(this *MainController, code int, msg interface{}) {
	if code >= 400 {
		beego.Error(msg)
	} else {
		beego.Info(msg)
	}
	this.Ctx.ResponseWriter.WriteHeader(code)
	// 讲msg值进行一个类型的转换,如果转换成功ok(true)
	b, ok := msg.([]byte)
	if ok {
		this.Ctx.ResponseWriter.Write(b)
	} else {
		s := msg.(string)
		this.Ctx.ResponseWriter.Write([]byte(s))
	}
}
